
public class Dog extends Animal {
	@Override 
	public String bark() {
		return "�۸�";
	}
	public Dog(String name) {
		super(name);
	}
}
